package repository;

import domain.Book;

public interface IBookRepository extends IRepository<Integer, Book>{
}
